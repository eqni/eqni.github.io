// Ball OOP
// Andrew Chen
// 1/25/2024
//
// Extra for Experts:
// - Decently accurate mouse in ball check
// - Different click modes and ball modifiers
//
// Instructions:
// - Press Q to toggle Rainbow Balls
// - Press A to toggle Auto Add Balls
// - Press S to change Mouse Modes(Add & Delete)
// - Press R to clear screen
// 
// Note: The eslint error has to be kept because it is necessary for my mouse in ball check function
//


// Variables
let balls = [];
let autoToggle = false;
let rgbBalls = false;
let ballColour;

let mouseMode = "add";
let mouseModes = ["add", "delete"];
let tempVariable;


// Setups up the simulation with 5 balls
function setup() {
  createCanvas(windowWidth, windowHeight);
  for (let i = 0; i < 5; i++) {
    addBall(random(0, windowWidth), random(0, windowHeight), 255);
  }
}

// Loads simulation
function draw() {
  noStroke();
  background(0);
  loadBalls();
  ballModifiers();
}

// Loads Modifiers
function ballModifiers() {
  // Automatically dispense balls
  if (autoToggle === true) {
    addBall(mouseX, mouseY, ballColour);
  }
  // Rainbow Balls
  if (rgbBalls === true) {
    ballColour = color(random(255), random(255), random(255));
  }
  else {
    ballColour = color(255);
  }
}

// Add or Delete Balls | Note: I chose to bind ball adding to the mouse click because I wanted to use keys for modifications instead
function mousePressed() {
  if (mouseMode === "delete") {
    checkIfPointInsideBall(mouseX, mouseY);
  }
  if (mouseMode === "add") {
    addBall(mouseX, mouseY, ballColour);
  }
}

// Toggle Modifiers
function keyPressed() {
  // Automatically Add Balls
  if (keyCode === 65) {
    autoToggle = !autoToggle;
  }

  // Rainbow Balls
  if (keyCode === 81) {
    rgbBalls = !rgbBalls;
  }

  // Clear Screen
  if (keyCode === 82) {
    balls = [];
  }

  // Switch Mouse Mode
  if (keyCode === 83) {
    for (let i = 0; i < mouseModes.length; i++) {
      if (mouseMode === mouseModes[i]) {
        tempVariable = (i + 1) % mouseModes.length;
      }
    }
    mouseMode = mouseModes[tempVariable];
  }
}

// Load Balls
function loadBalls() {
  for (let i = 0; i < balls.length; i++) {
    balls[i].update();
    balls[i].display();
  }
}

// Add a Ball
function addBall(x, y, color) {
  balls.push(new Ball(x, y, color));
}

// Checks if the mouse is in a Ball
function checkIfPointInsideBall(x, y) {
  for (let i = 0; i < balls.length; i++) {
    if (abs(x - balls[i].x) < balls[i].size && abs(y - balls[i].y) < balls[i].size && (x - balls[i].x) ^ 2 + (y - balls[i].y) ^ 2 < balls[i].size ^ 2) {
      balls.splice(i, 1);
    }
  }
}


// Ball Class
class Ball {
  constructor(x, y, colour) {
    this.x = x;
    this.y = y;
    this.xSpeed = random(-8, 8);
    this.ySpeed = random(-8, 8);
    this.size = random(25, 45);
    this.colour = colour;
  }

  update() {
    this.x += this.xSpeed;
    this.y += this.ySpeed;
    if (this.x > windowWidth || this.x < 0) {
      this.xSpeed = -this.xSpeed;
    }
    if (this.y > windowHeight || this.y < 0) {
      this.ySpeed = -this.ySpeed;
    }
  }

  display() {
    fill(this.colour);
    circle(this.x, this.y, this.size);
  }
}